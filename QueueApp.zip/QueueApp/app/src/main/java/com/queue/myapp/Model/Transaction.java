package com.queue.myapp.Model;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class Transaction {


    public String uid;
    public String type;
    public long time;


    public  String getDate()
    {
         return  new SimpleDateFormat("MM-dd-yyyy hh:mm:ss", Locale.ENGLISH).format(new Date(time));
    }

}
