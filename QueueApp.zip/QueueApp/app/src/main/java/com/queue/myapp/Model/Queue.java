package com.queue.myapp.Model;

public class Queue
{

    public String uid;
    public Long time;
    public  long queuecount=0;


}
