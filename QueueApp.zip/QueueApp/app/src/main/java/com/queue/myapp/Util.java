package com.queue.myapp;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.widget.Toast;

import com.google.android.material.snackbar.BaseTransientBottomBar;
import com.google.android.material.snackbar.Snackbar;

public class Util
{


    public static ProgressDialog getProgressDialog(Context context)
    {
        ProgressDialog progressDialog=new ProgressDialog(context);
        progressDialog.setCancelable(false);
        progressDialog.show();
        return progressDialog;
    }
    public  static  void showMessage(Activity activity, String Message)
    {
        Toast.makeText(activity,Message,Toast.LENGTH_LONG).show();
        Snackbar.make(activity.findViewById(android.R.id.content),Message, BaseTransientBottomBar.LENGTH_LONG).show();
    }

}
