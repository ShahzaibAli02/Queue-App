package com.queue.myapp.Activities;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;

import android.app.ProgressDialog;
import android.os.Bundle;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.queue.myapp.Adapter.TransactionAdapter;
import com.queue.myapp.Model.Transaction;
import com.queue.myapp.R;
import com.queue.myapp.Util;

import java.util.ArrayList;
import java.util.List;

public class HistoryActivity extends AppCompatActivity {

    RecyclerView recyclerView;
    List<Transaction> transactionList;
    TransactionAdapter transactionAdapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_history);
        recyclerView=findViewById(R.id.recyclerView);

        transactionList=new ArrayList<>();
        transactionAdapter=new TransactionAdapter(transactionList,this);
        recyclerView.setAdapter(transactionAdapter);


        loadData();
    }

    private void loadData()
    {
        ProgressDialog progressDialog = Util.getProgressDialog(this);
        progressDialog.setMessage("Loading Transactions..");
        FirebaseDatabase.getInstance()
                .getReference("Transactions")
                .child(FirebaseAuth.getInstance().getCurrentUser().getUid())
                .addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {

                        transactionList.clear();
                        progressDialog.dismiss();
                        if(!snapshot.exists())
                        {
                            Util.showMessage(HistoryActivity.this,"No Old Transactions Exist");
                        }
                        else
                        {
                            for(DataSnapshot dataSnapshot:snapshot.getChildren())
                            {

                                transactionList.add( dataSnapshot.getValue(Transaction.class));

                            }
                        }
                        transactionAdapter.notifyDataSetChanged();
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {

                        progressDialog.dismiss();
                        Util.showMessage(HistoryActivity.this,"Error");

                    }
                });

    }
}