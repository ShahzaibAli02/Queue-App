package com.queue.myapp.Adapter;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.button.MaterialButton;
import com.queue.myapp.Model.Transaction;
import com.queue.myapp.R;

import java.util.ArrayList;
import java.util.List;

public class TransactionAdapter extends RecyclerView.Adapter<TransactionAdapter.ViewHolder> {
    private List<Transaction>listData;
    Context context;
    public TransactionAdapter(List<Transaction> listData, Context context) {
        this.listData = listData;
        this.context=context;
    }
    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View view= LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.lyt_transaction,viewGroup,false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull final ViewHolder holder, int i) {
       Transaction transaction=listData.get(i);
       holder.txtNum.setText(String.valueOf(holder.getAdapterPosition()+1));
       holder.txtDate.setText(transaction.getDate());
       holder.txtType.setText(transaction.type);
    }

    @Override
    public int getItemCount() {
        return listData.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder{
        private TextView txtType,txtDate;
        private MaterialButton txtNum;

        public ViewHolder(View itemView)
        {
            super(itemView);
            txtNum=itemView.findViewById(R.id.txtNum);
            txtType=(TextView)itemView.findViewById(R.id.txtType);
            txtDate=itemView.findViewById(R.id.txtDate);

        }
    }

}
