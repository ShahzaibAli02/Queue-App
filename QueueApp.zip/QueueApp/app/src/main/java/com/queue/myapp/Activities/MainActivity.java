package com.queue.myapp.Activities;

import androidx.activity.result.ActivityResultLauncher;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.util.Log;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.button.MaterialButton;
import com.google.android.material.card.MaterialCardView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.zxing.client.android.Intents;
import com.journeyapps.barcodescanner.BarcodeView;
import com.journeyapps.barcodescanner.ScanContract;
import com.journeyapps.barcodescanner.ScanOptions;
import com.queue.myapp.Model.Queue;
import com.queue.myapp.Model.Transaction;
import com.queue.myapp.R;
import com.queue.myapp.Util;

import java.util.Calendar;
import java.util.Date;
import java.util.concurrent.TimeUnit;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {


    MaterialButton btnScanQr,btnScanQr2;
    MaterialCardView lytScanQr,lytYourTurn,lytWaiting;
    ProgressBar progressBar;
    String QUEUE_DB_REF="Queue";
    String QR_CONTENT="PRSQb$D!5X%Rgs&8";
    String uid;
    DatabaseReference databaseReference;
    CountDownTimer countDownTimer;
    boolean isCounterRunning=false;
    TextView txtQueueNum,txtWaitingTime;
    MaterialButton btnLogout,btnHistory,btnWithDraw,btnDeposit;
    LinearLayout lytTransactionType;
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        btnScanQr=findViewById(R.id.btnScanQr);
        btnScanQr2=findViewById(R.id.btnScanQr2);
        btnHistory=findViewById(R.id.btnHistory);
        lytTransactionType=findViewById(R.id.lytTransactionType);

        btnWithDraw=findViewById(R.id.btnWithDraw);
        btnDeposit=findViewById(R.id.btnDeposit);

        lytScanQr=findViewById(R.id.lytScanQr);
        lytWaiting=findViewById(R.id.lytWaiting);
        lytYourTurn=findViewById(R.id.lytYourTurn);

        txtQueueNum=findViewById(R.id.txtQueueNum);
        txtWaitingTime=findViewById(R.id.txtWaitingTime);
        btnLogout=findViewById(R.id.btnLogout);

        progressBar=findViewById(R.id.progressBar);
        btnScanQr.setOnClickListener(this);
        btnScanQr2.setOnClickListener(this);
        btnLogout.setOnClickListener(this);
        btnHistory.setOnClickListener(this);

        btnWithDraw.setOnClickListener(this);
        btnDeposit.setOnClickListener(this);

        uid= FirebaseAuth.getInstance().getCurrentUser().getUid();
        btnLogout.setText("Logout : "+FirebaseAuth.getInstance().getCurrentUser().getEmail());
        databaseReference= FirebaseDatabase.getInstance().getReference(QUEUE_DB_REF);
        checkIfInQueue();

    }


    //Method to check if the current user is already in queue
    private void checkIfInQueue()
    {

        hideAll();
        progressBar.setVisibility(View.VISIBLE);
        databaseReference
                .child(uid)
                .addListenerForSingleValueEvent(new ValueEventListener()
                {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot)
                    {

                        if(!snapshot.exists())
                        {
                            hideAll();
                            lytScanQr.setVisibility(View.VISIBLE);
                        }
                        else
                        {
                            listenForQueueUpdate();
                        }


                    }
                    @Override
                    public void onCancelled(@NonNull DatabaseError error)
                    {
                        hideAll();
                        Util.showMessage(MainActivity.this,"UnExpected Error | Check Internet Connection");
                    }
                });



    }

    public  void  scanQr()
    {
        ScanOptions options = new ScanOptions();
        options.setDesiredBarcodeFormats(ScanOptions.QR_CODE);
        options.setPrompt("Scan a barcode");
        options.setCameraId(0);
        options.setBeepEnabled(true);
        options.setBarcodeImageEnabled(true);

        barcodeLauncher.launch(options);
    }
    private final ActivityResultLauncher<ScanOptions> barcodeLauncher = registerForActivityResult(new ScanContract(),
            result ->
            {
                if(result.getContents() == null)
                {
                    Util.showMessage(MainActivity.this,"Error Failed To Scan QR");
                }
                else
                {

                    String strResult=result.getContents();
                    if(strResult.equals(QR_CONTENT))
                    {
                        joinQueue();
                    }
                    else
                    {
                        Util.showMessage(MainActivity.this,"Invalid QR | Please Scan Correct QR CODE");
                    }


                }
            });

    private void joinQueue()
    {
        hideAll();
        progressBar.setVisibility(View.VISIBLE);

        databaseReference.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {

                long count=0;

                if(snapshot.exists())
                {
                    count=snapshot.getChildrenCount();
                }

                Queue queue=new Queue();
                queue.uid=uid;
                queue.time= Calendar.getInstance().getTimeInMillis();
                queue.queuecount=count+1;
                databaseReference.child(queue.uid).setValue(queue);
                listenForQueueUpdate();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error)
            {
                hideAll();
                Util.showMessage(MainActivity.this,"UnExpected Error | Check Internet Connection");
            }
        });

    }

    private void listenForQueueUpdate()
    {
        databaseReference.addListenerForSingleValueEvent(new ValueEventListener()
        {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot)
            {
                hideAll();
                int queueCount=1;
                boolean isMyTurn=false;
                boolean iAmInList=false;
                long myWaitingTimeInSeconds=0;
                for(DataSnapshot child:snapshot.getChildren())
                {
                    Queue queue=child.getValue(Queue.class);
                    long secondsPassed = TimeUnit.MILLISECONDS.toSeconds(Calendar.getInstance().getTimeInMillis()-queue.time);
                    long secondsShouldPass= 60L *queue.queuecount;

                    if(queue.uid.equals(uid))
                    {
                        iAmInList=true;
                        myWaitingTimeInSeconds=secondsShouldPass-secondsPassed;
                    }
                    if(secondsPassed>=secondsShouldPass)
                    {
                        if(queue.uid.equals(uid))
                        {
                            isMyTurn=true;
                        }
                        databaseReference.child(queue.uid).removeValue();
                    }
                    else
                    {
                        if(!queue.uid.equals(uid))
                            queueCount++;
                    }
                }


                if(isMyTurn  || !iAmInList)
                {
                    lytYourTurn.setVisibility(View.VISIBLE);
                    lytTransactionType.setVisibility(View.VISIBLE);
                    if(isCounterRunning)
                    {
                        if(countDownTimer!=null)
                            countDownTimer.cancel();

                    }
                }
                else
                {
                    lytWaiting.setVisibility(View.VISIBLE);
                    txtQueueNum.setText(String.valueOf(queueCount));
                    if(!isCounterRunning)
                    {
                        startWaitingCount(myWaitingTimeInSeconds);
                    }

                }


            }
            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                hideAll();
                Util.showMessage(MainActivity.this,"UnExpected Error | Check Internet Connection");
            }
        });
    }

    private void startWaitingCount(long seconds)
    {


        countDownTimer=new CountDownTimer(seconds*1000,1000){

            @Override
            public void onTick(long l)
            {

                long totalSeconds=l/1000;

                if(totalSeconds%8==0)
                {
                    listenForQueueUpdate();
                }

                String strMinutes;
                String strSeconds;
                if(totalSeconds<=60)
                {
                 strMinutes="0";
                 strSeconds=String.valueOf(totalSeconds);
                }
                else
                {
                    long minutes=totalSeconds/60;
                    long seconds=totalSeconds-(minutes*60);
                    strMinutes=String.valueOf(minutes);
                    strSeconds=String.valueOf(seconds);
                }
                txtWaitingTime.setText(String.format("Estimated Waiting Time : %s Minutes %s Seconds",strMinutes,strSeconds));
            }

            @Override
            public void onFinish()
            {
                hideAll();
                isCounterRunning=false;
                databaseReference.child(uid).removeValue();
                lytYourTurn.setVisibility(View.VISIBLE);
                lytTransactionType.setVisibility(View.VISIBLE);
            }
        };
        countDownTimer.start();
        isCounterRunning=true;
    }


    private void hideAll()
    {
        progressBar.setVisibility(View.GONE);
        lytScanQr.setVisibility(View.GONE);
        lytWaiting.setVisibility(View.GONE);
        lytYourTurn.setVisibility(View.GONE);

    }


    @Override
    public void onClick(View view)
    {

        if(view==btnScanQr || view==btnScanQr2)
        {
            scanQr();
        }
        else
            if(view==btnDeposit || view==btnWithDraw)
            {
                lytTransactionType.setVisibility(View.GONE);
                String type=view==btnDeposit?"Deposit":"Withdraw";
                saveTransaction(type);
                Util.showMessage(this,"Transaction Saved");
            }
            else if(view==btnHistory)
            {
                startActivity(new Intent(this,HistoryActivity.class));
            }
        else
            if(view==btnLogout)
            {
                if(isCounterRunning)
                {
                    if(countDownTimer!=null)
                    countDownTimer.cancel();
                }
                FirebaseAuth.getInstance().signOut();
                finish();
                startActivity(new Intent(this,LoginActivity.class));

            }



    }

    private void saveTransaction(String type)
    {

        Transaction transaction=new Transaction();
        transaction.time=Calendar.getInstance().getTimeInMillis();
        transaction.type=type;
        transaction.uid=uid;
        FirebaseDatabase.getInstance()
                .getReference("Transactions")
                .child(uid)
                .push().setValue(transaction);

    }
}